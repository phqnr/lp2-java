package br.imd.model;

public class Gerente extends Funcionario{


    private String departamento;

    public Gerente(String nome, String dataNascimento, String cpf,  int matricula, String departamento) {
        super(nome, dataNascimento, cpf, matricula);
        this.departamento = departamento;
    }

    @Override
    public double calcularSalario() {
        return SALARIOMINIMO * 5.0;
    }

    @Override
    public void obterInfo() {
        String info0 = "\n###############################################\n";
        String info1= "Nome: " + this.nome + "\nCPF: " + this.cpf + "\nData da nascimento: " + this.dataNascimento;
        String info2 = "\nDepartamente" + this.departamento + "\nSalario: " + calcularSalario();
        System.out.println(info0 + info1 + info2);
    }

}
