package br.imd.model;

import java.util.ArrayList;

public class Empresa {

    ArrayList<Funcionario> funcionarios;
    private static Empresa maykonSoft;

    private Empresa(){
        funcionarios = new ArrayList<>();
    }


    //Padrão singleton (Cria apenas uma instancia de Empresa)
    public static Empresa getInstance(){
        if (maykonSoft == null){
            maykonSoft = new Empresa();
        }
        return maykonSoft;
    }

    //
    public void adicionarFuncionario(Funcionario funcionario) {
        funcionarios.add(funcionario);
    }

    public double calcularFolhaPagamento() {
        double folhaPagamento = 0;
        for (Funcionario funcionario : funcionarios) {
            folhaPagamento += funcionario.calcularSalario();
        }
        return folhaPagamento;
    }

    public void exibirInformacoesFuncionarios() {
        for (Funcionario funcionario : funcionarios) {
            funcionario.obterInfo();
        }
    }

}
