package br.imd.model;

public class Programador extends Funcionario {

    private String projetoAssociado;


    public Programador(String nome, String cpf, String dataNascimento, int matricula, String projetoAssociado) {
        super(nome, cpf, dataNascimento, matricula);
        this.projetoAssociado = projetoAssociado;
    }

    @Override
    public double calcularSalario() {
        return SALARIOMINIMO * 8.5;
    }

    @Override
    public void obterInfo() {
        String info0 = "\n###############################################\n";
        String info1= "Nome: " + this.nome + "\nCPF: " + this.cpf + "\nData da nascimento: " + this.dataNascimento;
        String info2 = "\nProjeto Associado:" + this.projetoAssociado + "\nSalario: " + calcularSalario();
        System.out.println(info0 + info1 + info2);
    }
}
