package br.imd.model;

public abstract class Funcionario {

    protected int matricula;
    protected String nome;
    protected String cpf;
    protected String dataNascimento;


    public static double SALARIOMINIMO = 1412.00;

    public Funcionario(String nome, String cpf, String dataNascimento, int matricula) {
        this.matricula = matricula;
        this.nome = nome;
        this.cpf = cpf;
        this.dataNascimento = dataNascimento;

    }

    public abstract double calcularSalario();

    public abstract void obterInfo();

}
