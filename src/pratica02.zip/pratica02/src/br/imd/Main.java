package br.imd;

import br.imd.model.Empresa;
import br.imd.model.Gerente;
import br.imd.model.Programador;

public class Main {
    public static void main(String[] args) {

        Empresa maykonSoft = Empresa.getInstance();

        maykonSoft.adicionarFuncionario(new Gerente("Francisco", "25/02/1995", "414.254.154-41", 1040302, "Matematica" ));
        maykonSoft.adicionarFuncionario(new Gerente("Pedro", "15/08/1975", "784.854.777-78", 4587487, "Quimica" ));
        maykonSoft.adicionarFuncionario(new Programador("Augusto", "12/12/2000", "145.254.154-41", 87458, "Sigaa" ));
        maykonSoft.adicionarFuncionario(new Programador("Jeorge", "02/05/2002", "895.254.154-41", 56522, "Sipac" ));


        maykonSoft.exibirInformacoesFuncionarios();

        System.out.println("\n\nFolha de pagamento total: " + maykonSoft.calcularFolhaPagamento());

    }
}